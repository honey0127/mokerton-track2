@echo off
REM 2차 라운드 프루닝 재학습 (학과 공용 PC, RTX 5070). 저장소 루트에 이 묶음을 덮어 복사한 뒤 저장소 루트에서 실행.
REM 순서: D 두 개(각 약 45분) -> B 두 개(각 약 2.5시간). 하나 끝날 때마다 runs\<이름>\weights\best.pt 가 생긴다.
REM 학습 설정은 A~D 와 같다 (epochs 100, batch 8, seed 0, mosaic, close_mosaic 10, patience 30).
python scripts\prune_p34.py train --pruned runs\prune\D_m60\pruned.pt --imgsz 640  --name D_m60
python scripts\prune_p34.py train --pruned runs\prune\D_m75\pruned.pt --imgsz 640  --name D_m75
python scripts\prune_p34.py train --pruned runs\prune\B_m75\pruned.pt --imgsz 1280 --name B_m75
python scripts\prune_p34.py train --pruned runs\prune\B_m60\pruned.pt --imgsz 1280 --name B_m60
