# 2차 라운드 묶음 (2026-10-15)

## 1. 프루닝 재학습 — 학과 공용 PC

1. 이 폴더의 `scripts/`, `runs/` 를 공용 PC 저장소(`D:\ibzago\mokerton-train` 등) 루트에 **덮어 복사**한다.
   기존 파일은 바뀌지 않고 `scripts/c2f_v2.py`, `scripts/prune_p34.py`, `runs/prune/` 만 추가된다.
2. 학습 환경(.venv-train)을 켜고 저장소 루트에서 `run_prune_train.bat` 실행.
   - ultralytics 는 **8.4.135** 여야 한다 (`pip show ultralytics` 로 확인. `pruned.pt` 가 이 버전으로 저장됐다)
   - torch-pruning 은 **필요 없다** (프루닝은 이미 끝난 상태로 `pruned.pt` 에 들어 있다).
3. 끝나면 아래 파일만 돌려준다 (맥 `ibizago` 폴더에 넣어 주면 내가 가져간다):
   `runs\D_m60\weights\best.pt`, `runs\D_m60\results.csv` (D_m75, B_m75, B_m60 도 같은 식)

| 이름 | 출발 | 연산량 (GFLOPs) | 파라미터 | 예상 학습 시간 |
|---|---|---|---|---|
| D_m60 | D (640x192) | 1.74 → 1.02 (−41%) | 1.85M → 1.25M | 약 45분 |
| D_m75 | D (640x192) | 1.74 → 1.28 (−26%) | 1.85M → 1.57M | 약 45분 |
| B_m75 | B (1280x384) | 6.95 → 5.11 (−26%) | 1.85M → 1.57M | 약 2.5시간 |
| B_m60 | B (1280x384) | 6.95 → 4.08 (−41%) | 1.85M → 1.25M | 약 2.5시간 |

내보내기(ONNX)·양자화·holdout 채점·M1 측정 준비는 내가 한다. 직접 export 하지 않는다
(`export_onnx.py` 는 가중치 이름이 `best` 라서 기존 `models/best_*.onnx` 를 덮어쓸 수 있다).

## 2. Hailo B·D HEF 컴파일 — 같은 공용 PC

`hailo/R2_BD_HEF.md` 순서대로. 프루닝 학습과 동시에 돌리면 GPU/CPU 를 나눠 써서 둘 다 느려지니
학습이 도는 동안에는 1~2단계(end node 확인, 보정 npy)까지만 해 두면 된다.
